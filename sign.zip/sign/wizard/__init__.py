# -*- coding: utf-8 -*-
# Part of Odoo. See LICENSE file for full copyright and licensing details.

from . import sign_send_request
from . import sign_template_share
from . import sign_request_send_copy
