# -*- coding: utf-8 -*-
# Part of Odoo. See LICENSE file for full copyright and licensing details.

from . import mailing_mailing
from . import mailing_trace
from . import marketing_campaign
from . import marketing_activity
from . import marketing_trace
