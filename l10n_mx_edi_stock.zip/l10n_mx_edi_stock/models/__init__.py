# -*- coding: utf-8 -*-

from . import l10n_mx_edi_vehicle
from . import res_partner
from . import stock_move_line
from . import stock_picking
