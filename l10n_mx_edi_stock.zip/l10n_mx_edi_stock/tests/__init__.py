# -*- coding: utf-8 -*-

from . import test_xml
from . import test_external
