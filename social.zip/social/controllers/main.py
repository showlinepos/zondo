class SocialValidationException(Exception):
    pass
