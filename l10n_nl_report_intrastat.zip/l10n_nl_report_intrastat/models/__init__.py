# -*- coding: utf-8 -*-

from . import l10n_nl_report_intrastat
