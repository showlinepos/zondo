# coding: utf-8
from . import test_l10n_co_edi
