# -*- coding: utf-8 -*-
from . import account_invoice
from . import account_tax
from . import account_journal
from . import product_template
from . import product_uom
from . import type_code
from . import res_partner
from . import tax_type
from . import carvajal_request
from . import res_company
from . import res_config_settings
from . import payment_option
from . import res_country_state
from . import res_city
