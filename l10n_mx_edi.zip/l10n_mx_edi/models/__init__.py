# -*- coding: utf-8 -*-

from . import account_bank_statement
from . import account_edi_format
from . import account_move
from . import account_payment
from . import account_journal
from . import account_payment_register
from . import ir_view
from . import l10n_mx_edi_certificate
from . import l10n_mx_edi_payment_method
from . import res_bank
from . import res_city
from . import res_company
from . import res_config_settings
from . import res_country
from . import res_currency
from . import res_partner
