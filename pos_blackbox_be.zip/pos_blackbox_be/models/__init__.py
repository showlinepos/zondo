# -*- coding: utf-8 -*-
# Part of Odoo. See LICENSE file for full copyright and licensing details.

from . import hr_employee
from . import pos_blackbox_be
from . import pos_config
from . import pos_order
from . import pos_order_pro_forma
from . import pos_session
from . import res_users
