# -*- coding: utf-8 -*-
# Part of Odoo. See LICENSE file for full copyright and licensing details.

from . import hr_payroll_employee_departure_holiday_attest
from . import hr_payroll_employee_departure_notice
from . import l10n_be_individual_account_wizard
from . import l10n_be_hr_payroll_credit_time_wizard
from . import hr_payroll_281_base_wizard
from . import hr_payroll_281_10_wizard
from . import hr_payroll_281_45_wizard
from . import hr_payroll_allocating_paid_time_off
