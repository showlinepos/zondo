# -*- coding:utf-8 -*-
# Part of Odoo. See LICENSE file for full copyright and licensing details.

from . import hr_employee
from . import res_config_settings
from . import res_users
from . import hr_contract
from . import hr_payslip
from . import hr_dmfa
from . import res_company
from . import hr_work_entry
from . import l10n_be_attachment_salary
from . import hr_payroll_structure_type
from . import hr_payslip_worked_days
from . import hr_leave
