# -*- coding: utf-8 -*-
# Part of Odoo. See LICENSE file for full copyright and licensing details.

from . import hr_individual_account_reports
from . import l10n_be_meal_voucher_report
from . import l10n_be_attachment_salary
from . import hr_contract_employee_report
from . import hr_281_10_templates
from . import hr_281_45_report
