# -*- encoding: utf-8 -*-
# Part of Odoo. See LICENSE file for full copyright and licensing details.

from . import account_generic_tax_report
from . import l10n_lu_yearly_tax_report_appendix
from . import l10n_lu_yearly_tax_report_manual
