# -*- encoding: utf-8 -*-

from . import test_prediction
