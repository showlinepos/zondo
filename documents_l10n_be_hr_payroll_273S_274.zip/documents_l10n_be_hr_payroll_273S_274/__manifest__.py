# -*- coding: utf-8 -*-
# Part of Odoo. See LICENSE file for full copyright and licensing details.

{
    'name': 'Belgian Payroll - 273S / 274.XX Sheets - Documents',
    'category': 'Human Resources',
    'summary': 'Withholding Taxes Exports in Documents',
    'depends': ['l10n_be_hr_payroll_273S_274', 'documents_l10n_be_hr_payroll'],
    'description': """
    """,
    'data': [],
    'qweb': [],
    'demo': [],
    'auto_install': True,
    'license': 'OEEL-1',
}
