# -*- coding: utf-8 -*-
from . import test_sale_subscription_sepa
