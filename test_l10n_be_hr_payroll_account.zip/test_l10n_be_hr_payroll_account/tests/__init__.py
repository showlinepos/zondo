# -*- coding: utf-8 -*-
# Part of Odoo. See LICENSE file for full copyright and licensing details.

from . import test_payslip
from . import test_double_pecule
from . import test_13th_month
from . import test_dmfa
from . import test_examples
from . import test_credit_time
from . import test_ui
from . import test_main_flow
from . import test_student
from . import test_payslips_validation
