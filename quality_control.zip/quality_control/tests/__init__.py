# -*- coding: utf-8 -*-
# Part of Odoo. See LICENSE file for full copyright and licensing details.
from . import test_common
from . import test_picking_quality_check
from . import test_purchase_quality_check
