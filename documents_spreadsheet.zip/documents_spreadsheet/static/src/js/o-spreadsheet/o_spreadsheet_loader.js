odoo.define("documents_spreadsheet.spreadsheet", function (require) {

    const _t = require("web.core")._t;
    window.o_spreadsheet.setTranslationMethod(_t);
    return window.o_spreadsheet;
});
