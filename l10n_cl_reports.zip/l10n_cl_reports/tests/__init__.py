# -*- coding: utf-8 -*-

from . import test_cl_eightcolumns_report
