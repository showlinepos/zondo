# -*- coding: utf-8 -*-
# Part of Odoo. See LICENSE file for full copyright and licensing details

from . import test_industry_fsm_sale_flow
from . import test_multicompany
