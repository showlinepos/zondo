# -*- coding: utf-8 -*-

from . import pos_loyalty
from . import pos_config
from . import res_partner
from . import pos_order
from . import product
