# -*- coding: utf-8 -*-
from . import product
from . import rental_pricing
from . import res_company
from . import res_config_settings
from . import sale
