# -*- coding: utf-8 -*-

from . import stock_inventory
from . import stock_picking
from . import stock_scrap
from . import stock_location
from . import stock_move_line
from . import stock_quant_package
from . import product_product
from . import res_company
from . import res_config_settings
