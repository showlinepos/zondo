# -*- coding: utf-8 -*-

from . import account_generic_tax_report