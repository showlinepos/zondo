# -*- coding: utf-8 -*-
# Part of Odoo. See LICENSE file for full copyright and licensing details.

from . import test_edi_xmls
from . import test_edi_digiflow
from . import test_edi_sunat
from . import test_edi_iap
