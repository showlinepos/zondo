# -*- coding: utf-8 -*-
# Part of Odoo. See LICENSE file for full copyright and licensing details.

from . import delivery_ups
from . import product_packaging
from . import sale
from . import res_partner
