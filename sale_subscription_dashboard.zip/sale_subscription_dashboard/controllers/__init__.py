# -*- coding: utf-8 -*-
# Part of Odoo. See LICENSE file for full copyright and licensing details.

from . import revenue_kpis_dashboard
from . import salesman_dashboard
from . import stat_types
