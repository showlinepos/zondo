# -*- coding: utf-8 -*-
# Part of Odoo. See LICENSE file for full copyright and licensing details.

from . import ir_action
from . import ir_ui_view
from . import res_partner 
from . import res_config_settings
from . import models
from . import ir_http
