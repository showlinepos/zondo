# -*- encoding: utf-8 -*-
# Part of Odoo. See LICENSE file for full copyright and licensing details.

from . import hr_appraisal
from . import res_company
from . import res_config_settings
from . import survey
