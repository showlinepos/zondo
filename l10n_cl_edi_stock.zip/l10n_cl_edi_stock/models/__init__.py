# -*- coding: utf-8 -*-
from . import account_move
from . import l10n_latam_document_type
from . import res_partner
from . import stock_picking

