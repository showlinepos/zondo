# -*- encoding: utf-8 -*-

from . import test_online_sync_creation_statement
