# -*- coding: utf-8 -*-

from . import l10n_mx_edi_tariff_fraction
from . import l10n_mx_edi_locality
from . import product_template
from . import uom_uom
from . import account_journal
from . import account_move
from . import res_partner
from . import res_company
from . import res_config_settings
from . import account_edi_format
