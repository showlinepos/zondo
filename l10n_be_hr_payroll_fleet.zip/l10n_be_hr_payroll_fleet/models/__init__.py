# -*- coding:utf-8 -*-
# Part of Odoo. See LICENSE file for full copyright and licensing details.

from . import fleet
from . import res_config_settings
from . import hr_contract
from . import hr_dmfa
from . import hr_payslip
