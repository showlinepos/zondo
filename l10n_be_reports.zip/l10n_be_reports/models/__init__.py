# -*- coding: utf-8 -*-
# Part of Odoo. See LICENSE file for full copyright and licensing details.

from . import account_generic_tax_report
from . import account_report
from . import account_tax_report
from . import partner_vat_listing
from . import partner_vat_intra
from . import assets_report
from . import res_partner
