# -*- coding: utf-8 -*-
# Part of Odoo. See LICENSE file for full copyright and licensing details.

from . import hr_referral_link_to_share
from . import hr_referral_send_mail
