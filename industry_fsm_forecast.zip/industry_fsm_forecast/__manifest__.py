# -*- coding: utf-8 -*-
# Part of Odoo. See LICENSE file for full copyright and licensing details.
{
    'name': "Field Service - Project Forecast",
    'summary': "",
    'description': """""",
    'category': 'Services/Field Service',
    'version': '1.0',
    'depends': ['industry_fsm', 'project_forecast'],
    'data': [],
    'application': False,
    'auto_install': True,
    'license': 'OEEL-1',
}
