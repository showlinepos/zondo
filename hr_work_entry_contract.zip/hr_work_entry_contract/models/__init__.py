# -*- coding:utf-8 -*-
# Part of Odoo. See LICENSE file for full copyright and licensing details.

from . import hr_contract
from . import hr_employee
from . import hr_work_entry
from . import hr_work_intervals
